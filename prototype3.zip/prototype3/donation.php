<!DOCTYPE html>
<html>
<head>
	<title>Lend 4 Care - Donation</title>

	<!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="bootstrap-3.3.7/css/bootstrap.min.css">
    
    <!-- Optional theme -->
    <link rel="stylesheet" href="bootstrap-3.3.7/css/bootstrap-theme.min.css">
    
    <!-- Latest compiled and minified JavaScript -->
    <script src="bootstrap-3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <a href="#">
            <img src="images/lend4care.png" style="height: 55px">
          </a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="../navbar/">Default</a></li>
            <li><a href="../navbar-static-top/">Static top</a></li>
            <li class="active"><a href="./">Fixed top <span class="sr-only">(current)</span></a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
      	</br>
      	<h1 style="text-align: center">Donate for:</h1>
        <h2 style="text-align: center">*Insert Name of Case (eg. Lolo Alfredo reported by Juan)*</h2>
        <h4 style="text-align: center">Sector: Senior Citizen</h4>
        <!--</br>
        <h3 style="text-align: center">I donate:</h3> 
        <div class="input-group input-group-sm" style="margin-left: 475px">
		  <span class="input-group-addon">&#8369;</span>
		  <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)" style="width:150px;">
		</div>-->

      </div>
    </div>




    <!-- <ul class="nav nav-tabs" style="width: 270px; margin-left: 550px" >
		<li role="presentation" class="active"><a href="#">Home</a></li>
		<li role="presentation"><a href="#">Profile</a></li>
		<li role="presentation"><a href="#">Messages</a></li>
	</ul> -->

    <!--margin-left: 380px; margin-bottom: 20px -->

<div class="container">
	<div class="well">
            <h1>Donation Form</h1>

                <div class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-user"></i></span>
                            <input class="span12" placeholder="Full name" id="inputIcon" type="text" required="required">
                        </div>
                    </div>
                </div>

                <div class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-envelope"></i></span>
                            <input class="span12" placeholder="Your Email" id="inputIcon" type="email" required="required">
                        </div>
                    </div>
                </div>

                <div class="control-group">
                    <div class="controls">
                        <div class="input-prepend">
                            <span class="add-on"><i class="icon-phone"></i></span>
                            <input class="span12" placeholder="Telephone" id="inputIcon" type="tel">
                        </div>
                    </div>
                </div>

			    <div class="btn-toolbar">
			      <div class="btn-group" required="required">

			        <strong>Select your donation</strong>

				    <div class="control-group label-small">
				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">Foods</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">New Clothes</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">Mats</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">New Toiletries</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">Blankets</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">Tents</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="Value">Utensils</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="123">New Toys</label>

				        <label class="checkbox"><input type="checkbox" name="checkboxes" value="123">Other</label>
				    </div>

			      </div>
			    </div>

                <div class="controls">
                    <textarea id="message" name="message" class="span12" placeholder="Your Message" rows="5" required="required"></textarea>
                </div>
               
                <button class="btn btn-primary" type="button">Send</button>
    </div>
</div>


</body>
</html>