<?php
session_start();
ini_set("display_errors", "0");
        // Include Medoo
        require 'medoo/medoo.php';

        // Initialize
        $database = new medoo([
            'database_type' => 'mysql',
            'database_name' => 'lend4caredb',
            'server' => 'localhost',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8'
        ]);

//Account Settings
if(isset($_POST['usereditBtn'])){

    $username = $_POST['useredit'];
    $database->update('user', ["uname"=>$username],["userID"=>$_SESSION["userID"]]); 
    $_SESSION["uname"] = $username;
    header("Location: account_settings.php");
    
}elseif(isset($_POST['passeditBtn'])){
    
    if($_POST['oldpword']==$_SESSION["pword"]){
        if($_POST['newpword']==$_POST['conpword']){
        $password = $_POST['newpword'];
        $database->update('user', ["pword"=>$password],["userID"=>$_SESSION["userID"]]);
        }
    }
    header("Location: account_settings.php");
    
    
}elseif(isset($_POST['anoneditBtn'])){
    
    $anon = $_POST['anonedit'];
    $database->update('user', ["anonymous"=>$anon],["userID"=>$_SESSION["userID"]]);
    $_SESSION["anonymous"] = $anon;
    header("Location: account_settings.php");
    
}elseif(isset($_POST['emaileditBtn'])){
    
    $email = $_POST['emailedit'];
    $database->update('user', ["email"=>$email],["userID"=>$_SESSION["userID"]]);
    $_SESSION["email"] = $email;
    header("Location: account_settings.php");
    
    
//Profile Settings
    
}elseif(isset($_POST['bdayeditBtn'])){
    
    $bday = $_POST['bdayedit'];
    $database->update('user', ["bday"=>$bday],["userID"=>$_SESSION["userID"]]);
    $_SESSION["bday"] = $bday;
    header("Location: user_profile.php");
    
}elseif(isset($_POST['addresseditBtn'])){
    
    $address_no = $_POST['address_no'];
    $address_st = $_POST['address_st'];
    $address_brgy = $_POST['address_brgy'];
    $address_city = $_POST['address_city'];
    $address_state = $_POST['address_state'];
    $address_district = $_POST['address_district'];
    $address_region = $_POST['address_region'];
    
    $database->update('user',["address_no"=>$address_no, "address_st"=>$address_st, "address_brgy"=>$address_brgy, "address_city"=>$address_city, "address_state"=>$address_state, "address_district"=>$address_district, "address_region"=>$address_region],["uname"=>$_SESSION["user"]]);
    
    $_SESSION["address_no"] = $address_no;
    $_SESSION["address_st"] = $address_st;
    $_SESSION["address_brgy"] = $address_brgy;
    $_SESSION["address_city"] = $address_city;
    $_SESSION["address_state"] = $address_state;
    $_SESSION["address_district"] = $address_district;
    $_SESSION["address_region"] = $address_region;
    
    header("Location: user_profile.php");
    
}elseif(isset($_POST['cpeditBtn'])){
    
    $cp = $_POST['cpedit'];
    $database->update('user', ["cp"=>$cp],["userID"=>$_SESSION["userID"]]);
    $_SESSION["cp"] = $cp;
    header("Location: user_profile.php");
    
}elseif(isset($_POST['tpeditBtn'])){
    
    $tp = $_POST['tpedit'];
    $database->update('user', ["tp"=>$tp],["userID"=>$_SESSION["userID"]]);
    $_SESSION["tp"] = $tp;
    header("Location: user_profile.php");
    
}



//

?>