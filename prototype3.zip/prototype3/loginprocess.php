<?php
session_start();
ini_set("display_errors", "0");
		// Include Medoo
		require 'medoo/medoo.php';
 
		// Initialize
		$database = new medoo([
			'database_type' => 'mysql',
			'database_name' => 'lend4caredb',
			'server' => 'localhost',
			'username' => 'root',
			'password' => '',
			'charset' => 'utf8'
		]);

$user = $_POST['user'];
$pass = $_POST['pass'];

$account = $database->select('user', 
    '*', 
    array('uname'=>$user)
);

if($pass==$account[0]['pword']){
    
    $_SESSION["anonymous"] = $account[0]['anonymous'];
    $_SESSION["uname"] = $account[0]['uname'];
    $_SESSION["pword"] = $account[0]['pword'];
    $_SESSION["userID"] = $account[0]['userID'];
    $_SESSION["fname"] = $account[0]['fname'];
    $_SESSION["lname"] = $account[0]['lname'];
    $_SESSION["mname"] = $account[0]['mname'];
    $_SESSION["gender"] = $account[0]['gender'];
    $_SESSION["bday"] = $account[0]['bday'];
    $_SESSION["tp"] = $account[0]['tp'];
    $_SESSION["cp"] = $account[0]['cp'];
    $_SESSION["address_no"] = $account[0]['address_no'];
    $_SESSION["address_st"] = $account[0]['address_st'];
    $_SESSION["address_brgy"] = $account[0]['address_brgy'];
    $_SESSION["address_district"] = $account[0]['address_district'];
    $_SESSION["address_city"] = $account[0]['address_city'];
    $_SESSION["address_state"] = $account[0]['address_state'];
    $_SESSION["address_region"] = $account[0]['address_region'];
    $_SESSION["email"] = $account[0]['email'];
    $_SESSION["profilepic"] = $account[0]['profilepic'];
    
    $_SESSION["con"] = "1";
    if($account[0]['userlvID']==3){
        header("Location: index.php");
    }elseif($account[0]['userlvID']==2){
        header("Location: viewprocess.php");    
    }
}else{
//    echo 'Incorrect Username or Password!';

    header("Location: log_in.php");

        
}

?>


