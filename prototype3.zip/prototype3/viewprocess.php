<?php
session_start();
ini_set("display_errors", "0");
		// Include Medoo
		require 'medoo/medoo.php';
 
		// Initialize
		$database = new medoo([
			'database_type' => 'mysql',
			'database_name' => 'lend4caredb',
			'server' => 'localhost',
			'username' => 'root',
			'password' => '',
			'charset' => 'utf8'
		]);


//Branches
$branch = $database->select('branch',array('branchID','name','address_no','address_st','address_brgy', 'address_district', 'address_city','address_state','address_region','email','tp','cp'));


$x=0;
foreach($branch as $branch2){
$_SESSION["branchID"][$x] = $branch2['branchID'];
$_SESSION["branchname"][$x] = $branch2['name'];
$_SESSION["branchadd_no"][$x] = $branch2['address_no'];
$_SESSION["branchadd_st"][$x] = $branch2['address_st'];
$_SESSION["branchadd_brgy"][$x] = $branch2['address_brgy'];
$_SESSION["branchadd_district"][$x] = $branch2['address_district'];
$_SESSION["branchadd_city"][$x] = $branch2['address_city'];
$_SESSION["branchadd_state"][$x] = $branch2['address_state'];
$_SESSION["branchadd_region"][$x] = $branch2['address_region'];
$_SESSION["branchemail"][$x] = $branch2['email'];
$_SESSION["branchtp"][$x] = $branch2['tp'];
$_SESSION["branchcp"][$x] = $branch2['cp'];
$x = $x + 1;
}

$_SESSION["count1"] = $x;




//Users - Moderators

$moderator = $database->select('user', 
    array('userlvID','uname', 'pword', 'fname', 'lname', 'mname', 'gender', 'bday', 'tp', 'cp', 'address_no', 'address_st', 'address_brgy', 'address_district', 'address_city', 'address_state', 'address_region'), 
    array('userlvID'=>"2")
);

$x=0;
foreach($moderator as $moderator2){
$_SESSION["mod_uname"][$x] = $moderator2['uname'];
$_SESSION["mod_fname"][$x] = $moderator2['fname'];
$_SESSION["mod_lname"][$x] = $moderator2['lname'];
$_SESSION["mod_mname"][$x] = $moderator2['mname'];
$_SESSION["mod_gender"][$x] = $moderator2['gender'];
$_SESSION["mod_bday"][$x] = $moderator2['bday'];
$_SESSION["mod_tp"][$x] = $moderator2['tp'];
$_SESSION["mod_cp"][$x] = $moderator2['cp'];
$_SESSION["modadd_no"][$x] = $moderator2['address_no'];
$_SESSION["modadd_st"][$x] = $moderator2['address_st'];
$_SESSION["modadd_brgy"][$x] = $moderator2['address_brgy'];
$_SESSION["modadd_district"][$x] = $moderator2['address_district'];
$_SESSION["modadd_city"][$x] = $moderator2['address_city'];
$_SESSION["modadd_state"][$x] = $moderator2['address_state'];
$_SESSION["modadd_region"][$x] = $moderator2['address_region'];
$x = $x + 1;
}

$_SESSION["count2"] = $x;


//Users - Netizens

$netizen = $database->select('user', 
    array('userlvID','uname', 'pword', 'fname', 'lname', 'mname', 'gender', 'bday', 'tp', 'cp', 'address_no', 'address_st', 'address_brgy', 'address_district', 'address_city', 'address_state', 'address_region'), 
    array('userlvID'=>"3")
);


$x=0;
foreach($netizen as $netizen2){
$_SESSION["net_uname"][$x] = $netizen2['uname'];
$_SESSION["net_fname"][$x] = $netizen2['fname'];
$_SESSION["net_lname"][$x] = $netizen2['lname'];
$_SESSION["net_mname"][$x] = $netizen2['mname'];
$_SESSION["net_gender"][$x] = $netizen2['gender'];
$_SESSION["net_bday"][$x] = $netizen2['bday'];
$_SESSION["net_tp"][$x] = $netizen2['tp'];
$_SESSION["net_cp"][$x] = $netizen2['cp'];
$_SESSION["netadd_no"][$x] = $netizen2['address_no'];
$_SESSION["netadd_st"][$x] = $netizen2['address_st'];
$_SESSION["netadd_brgy"][$x] = $netizen2['address_brgy'];
$_SESSION["netadd_district"][$x] = $netizen2['address_district'];
$_SESSION["netadd_city"][$x] = $netizen2['address_city'];
$_SESSION["netadd_state"][$x] = $netizen2['address_state'];
$_SESSION["netadd_region"][$x] = $netizen2['address_region'];
$x = $x + 1;
}

$_SESSION["count3"] = $x;


//Sectors

$sector = $database->select('sector',array('sectorID','name'));

$x=0;
foreach($sector as $sector2){
$_SESSION["sectorID"][$x] = $sector2['sectorID'];
$_SESSION["sectorname"][$x] = $sector2['name'];
$x = $x + 1;
}
    
$_SESSION["count4"] = $x;
    
header("Location: admin_panel.php");
//
?>