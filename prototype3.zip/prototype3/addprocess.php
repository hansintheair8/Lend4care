<?php
session_start();
ini_set("display_errors", "0");
		// Include Medoo
		require 'medoo/medoo.php';
 
		// Initialize
		$database = new medoo([
			'database_type' => 'mysql',
			'database_name' => 'lend4caredb',
			'server' => 'localhost',
			'username' => 'root',
			'password' => '',
			'charset' => 'utf8'
		]);

//Register

if(isset($_POST['registerbtn'])){
    
        $target_dir = "img/profilepic/";
        include("uploadprocess.php");    
    
        $imagepath = $target_file;
		$username = $_POST['username'];
		$password = $_POST['password'];
        $conpass = $_POST['conpassword'];
    
		$lname = $_POST['lname'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$gender = $_POST['gender'];

		date_default_timezone_set('Asia/Manila');
		$datecreated = date('Y-m-d H:i:s');
	
        $bday = $_POST['bday'];
    
		$region = $_POST['region'];
		$state = $_POST['state'];
		$city = $_POST['city'];
		$district = $_POST['district'];
		$addressno = $_POST['addressno'];
		$addressstreet = $_POST['addressstreet'];
		$addressbarangay = $_POST['addressbarangay'];
		$landline = $_POST['landline'];
		$mobilenum = $_POST['mobilenum'];
		$email = $_POST['email'];
        
       
    
		if(strcmp($password,$conpass)==0){
            
		$database->insert("user", ["userlvID" => '3',"date_created" => $datecreated,"uname" => $username,"pword" => $password,"lname" => $lname,"fname" => $fname,"mname" => $mname,"gender" => $gender,"bday" => $bday,"address_region" => $region,"address_state" => $state,"address_city" => $city,"address_district" => $district,"address_no" => $addressno,"address_st" => $addressstreet,"address_brgy" => $addressbarangay,"tp" => $landline,"cp" => $mobilenum,"email" => $email,"profilepic"=>$imagepath]);

		
        header("Location: index.php");
            
        }else{
        header("Location: register.php");
        }
    
}elseif(isset($_POST['addreportbtn'])){
//Add Report
    
        $target_dir = "uploads/";
        include("uploadprocess.php");    
    
        $imagepath = $target_file;
        $sector = $_POST['sector'];
        $situation = $_POST['situation'];
        $subject = $_POST['subject'];
        $sight_no = $_POST['sight_no'];
        $sight_st = $_POST['sight_st'];
        $sight_brgy = $_POST['sight_brgy'];
        $sight_district = $_POST['sight_district'];
        $sight_city = $_POST['sight_city'];
        $sight_state = $_POST['sight_state'];
        $sight_region = $_POST['sight_region'];
        $time_hour = $_POST['time_hour'];
        $time_min = $_POST['time_min'];
    
        date_default_timezone_set('Asia/Manila');
		$reportcreated = date('Y-m-d H:i:s');
    
        $sight_date = $_POST["sight_date"];
        $sight_time = $time_hour.":".$time_min.":"."00";
        
    
        $database->insert("report", ["userID"=>$_SESSION["userID"],"evidence"=>$imagepath,"sectorID"=>$sector,"situation"=>$situation,"subject"=>$subject,"place_sighted_no"=>$sight_no,"place_sighted_st"=>$sight_st,"place_sighted_brgy"=>$sight_brgy, "place_sighted_district"=>$sight_district,"place_sighted_city"=>$sight_city, "place_sighted_state"=>$sight_state, "place_sighted_region"=>$sight_region,"date_sighted"=>$sight_date,"time_sighted"=>$sight_time,"new"=>"0","reportstatusID"=>"2","affirm"=>"0","censorID"=>"1","date_created"=>$reportcreated]);
    
         header("Location: user_reports.php");
    
}elseif(isset($_POST['addbranchbtn'])){
//Add Branch
    
        $branchname = $_POST['branchname'];
        $branchadd_no = $_POST['branchadd_no'];
        $branchadd_st = $_POST['branchadd_st'];
        $branchadd_brgy = $_POST['branchadd_brgy'];
        $branchadd_district = $_POST['branchadd_district'];
        $branchadd_city = $_POST['branchadd_city'];
        $branchadd_state = $_POST['branchadd_state'];
        $branchadd_region = $_POST['branchadd_region'];
        $branchemail = $_POST['branchemail'];
        $branchtp = $_POST['branchtp'];
        $branchcp = $_POST['branchcp'];
        //$branchpword = $_POST['branchpword'];

        $database->insert("branch", ["name"=>$branchname,"address_no"=>$branchadd_no,"address_st"=>$branchadd_st,"address_brgy"=>$branchadd_brgy,"address_district"=>$branchadd_district,"address_city"=>$branchadd_city,"address_state"=>$branchadd_state,"address_region"=>$branchadd_region,"email"=>$branchemail,"tp"=>$branchtp,"cp"=>$branchcp,"pword"=>"1"]);
    
        header("Location: admin_branch.php");
    
}elseif(isset($_POST['addsectorbtn'])){
//Add Sector
        
        $sectorname = $_POST['sectorname'];
        $database->insert("sector", ["name"=>$sectorname]); 
    
        header("Location: admin_sector.php");
}
?>