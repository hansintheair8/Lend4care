<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care - Admin</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->

</head>

<body>
  <!-- container section start -->
  <section id="container" class="">

      <!--header start-->
      <header class="header navbar-fixed-top dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <a href="index.php" class="logo"><img alt="" src="img/favicon32x32.ico"><span class="lite">&nbsp;LEND4CARE</span></a>

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">

                    <li>
                        <a href="index.php">
                            <i class="icon-home-l"></i>
                        </a>
                    </li>

                    <!-- notification start-->
                    <li id="alert_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                            <i class="icon-bell-l"></i>
                            <span class="badge bg-important">7</span>
                        </a>
                        <ul class="dropdown-menu extended notification">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 3 new notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-primary"><i class="icon_like"></i></span> 
                                    Congratulations, your report has been heard!
                                    <span class="small italic pull-right">5 mins</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-danger"><i class="icon_book_alt"></i></span> 
                                    Your report has been disapproved.
                                    <span class="small italic pull-right">1 hr</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-success"><i class="icon_like"></i></span> 
                                    Your report has been approved.
                                    <span class="small italic pull-right"> Today</span>
                                </a>
                            </li>                            
                            <li>
                                <a href="#">See all notifications</a>
                            </li>
                        </ul>
                    </li>
                    <!-- notification end-->
                    
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="<?php echo $_SESSION["profilepic"]; ?>" style="width:30px; height:30px;">
                            </span>
                            <span class="username"><?php echo $_SESSION["fname"]." ".$_SESSION["lname"]; ?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li class="eborder-top">
                                <a href="#"><i class="icon_profile"></i> My Profile</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_clock_alt"></i> Timeline</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                            </li>
                            <li>
                                <a href="log-out.php"><i class="icon_key_alt"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->

      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li>
                      <a class="" href="admin_panel.php">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
                  <li>
                      <a href="admin_branch.php" class="">
                          <i class="icon_map"></i>
                          <span>Branches</span>
                      </a>
                  </li>       
                  <li class="sub-menu active">
                      <a href="javascript:;" class="">
                          <i class="icon_profile"></i>
                          <span>Users</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">                          
                          <li><a class="" href="admin_user_moderators.php">Moderators</a></li>
                          <li><a class="" href="admin_user_netizens.php"><span>Netizens</span></a></li>
                      </ul>
                  </li>
                  <li>
                      <a href="admin_sector.php">
                          <i class="icon_globe-2"></i>
                          <span>Sectors</span>
                      </a>
                  </li>     
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Reports</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="admin_report_pending.php">Pending</a></li>
                          <li><a class="" href="admin_report_approved.php">Approved</a></li>
                          <li><a class="" href="admin_report_ongoing.php">On-Going</a></li>
                          <li><a class="" href="admin_report_resolved.php">Resolved</a></li>
                          <li><a class="" href="admin_report_disapproved.php">Disapproved</a></li>
                      </ul>
                  </li>
                  <li>
                      <a href="admin_announcement.php" class="">
                          <i class="icon_table"></i>
                          <span>Announcements</span>
                      </a>
                  </li>                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

      <!--main content start-->
      <section id="main-content" style="margin-left: 180px;">
          <section class="wrapper">
              <div class="row">
                  <div class="col-lg-12">
                    <h3 class="page-header">Users</h3>
                    <ol class="breadcrumb">
                      <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                      <li><i class="icon_profile"></i>Users</li>
                      <li><i class="icon_profile"></i>Netizens</li>
                    </ol>
                  </div>
              </div>
              <!-- page start-->
              <div class="row">
                  <div class="col-lg-12">
                      <div class="form-group">
                          <h4><label for="search">Search:</label></h4>
                          <input name="search" type="search" class="form-control" pattern="[^'\x22]+" title="Invalid input" id="search">
                      </div>
                      <section class="panel">
                          <header class="panel-heading">
                              Netizens
                          </header>
                          
                          <table class="table table-striped table-advance table-hover">
                           <tbody>
                              <tr>
                                 <th>ID</th>
                                 <th>Username</th>
                                 <th>Name</th>
                                 <th>Address</th>
                                 <th>Gender</th>
                                 <th>Birthday</th>
                                 <th>Email</th>
                                 <th>Phone Number</th>
                                 <th>Type</th>
                                 <th>Action</th>
                              </tr>
                               
                               <?php for($x=0;$x<$_SESSION["count3"];$x++): ?>
                              <tr>
                                 <td>1</td>
                                 <td>hansintheair8</td>
                                 <td>Hans Del Rosario</td>
                                 <td>#8 Acacia St. Pasic City</td>
                                 <td>Male</td>
                                 <td>12/22/1891</td>
                                 <td>hansventedosx@gmail.com</td>
                                 <td>176-026-5992</td>
                                 <td>Anonymous</td>                                 
                                 <td>
                                  <div class="btn-group btn-group-xs">
                                      <a class="btn btn-primary tooltips" data-original-title="View" data-placement="left" data-toggle="modal" href="#myModalView"><i class="icon_check_alt2"></i></a>
                                      <a class="btn btn-success tooltips" data-original-title="Edit" data-placement="left" data-toggle="modal" href="#myModalEdit"><i class="icon_pencil"></i></a>
                                      <a class="btn btn-danger tooltips" data-original-title="Delete" data-placement="left" data-toggle="modal" href="#myModalDelete"><i class="icon_trash_alt"></i></a>
                                  </div>
                                  </td>
                              </tr> 
                                <?php endfor; ?>
                               
                           </tbody>
                        </table>
                      </section>
                  </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->

      <!-- footer -->
      <div class="text-right">
            <div class="col-lg-12">
                <div class="copy-right">
                        <p class="footer-gd">Designed by Team ACE | Powered by BootstrapMade</a></p>
                </div>
            </div>
      </div>

  </section>
  <!-- container section end -->


<!--Modals-->
    <!-- Modal View-->
    <div id="myModalView" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">View Netizens</h4>
          </div>
          <div class="modal-body">
              <h4>User Name:</h4>
              <p>hansintheair8</p>
              <h4>Name:</h4>
              <p>Hans Del Rosario</p>
              <h4>Address:</h4>
              <p>#8 Acacia St. Pasic City</p>
              <h4>Gender</h4>
              <p>Female</p>
              <h4>Birthday:</h4>
              <p>12/22/1891</p>
              <h4>Email:</h4>
              <p>hansventedosx@gmail.com</p>
              <h4>Phone Number:</h4>
              <p>176-026-5992</p> 
              <h4>Type:</h4>
              <p>Anonymous</p>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </div>
        </div>

      </div>
    </div>


    <!-- Modal Edit-->
    <div id="myModalEdit" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Moderator</h4>
          </div>
          <div class="modal-body">
                <form role="form" name="demo" action="" class="demo" method="POST">
                      <div class="form-group">
                        <label for="moderatorID">ID:</label>
                        <input name="moderatorID" type="text" class="form-control" pattern="[0-9]*" id="disabledInput" disabled/>
                      </div>
                      <div class="form-group">
                        <label for="uname">User Name:</label>
                        <input name="uname" type="text" class="form-control" pattern="[a-zA-Z0-9]*" id="uname" required/>
                      </div>
                      <div class="form-group">
                        <label for="lname">Last Name:</label>
                        <input name="lname" type="text" class="form-control" pattern="[a-zA-Z]*" id="lname" required/>
                      </div>
                      <div class="form-group">
                        <label for="fname">First Name:</label>
                        <input name="fname" type="text" class="form-control" pattern="[a-zA-Z]*" id="fname" required/>
                      </div>
                      <div class="form-group">
                        <label for="mname">Middle Name:</label>
                        <input name="mname" type="text" class="form-control" pattern="[a-zA-Z]*" id="mname" required/>
                      </div>
                      <div class="form-group">
                        <label for="branchname">Branch:</label>
                        <select class="form-control" required/>
                            <option name="branchname">-</option>
                            <option name="branchname">DSWD NCR Manila</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="email">Email:</label>
                        <input name="email" type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" id="email" required/>
                      </div>
                      <div class="form-group">
                        <label for="phonenum">Phone Number:</label>
                        <input name="phonenum" type="text" class="form-control" pattern="[0-9]*" id="phonenum" required/>
                      </div>

                      <button type="submit" class="btn btn-primary">Submit</button>
                </form>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </div>
        </div>

      </div>
    </div>


    <!-- Modal Delete-->
    <div id="myModalDelete" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Delete Netizen</h4>
          </div>
          <div class="modal-body">
                <p>Do you really want to delete this row?</p>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Yes</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal">No</button>
          </div>
          </div>
        </div>
      </div>
<!-- End Modals-->


<!-- javascripts -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="js/scripts.js"></script>

<script>

  //knob
  $(".knob").knob();

</script>


</body>
</html>
