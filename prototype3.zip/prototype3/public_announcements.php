<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care- Public Reports</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/modern-business.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/temp.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->

</head>

<body class="parallax">

<!--header start-->
<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.html" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li><a href="index.html">Home</a></li>
          <li class="active"><a href="public_announcements.html">Public Announcements</a></li>
          <li><a href="public_reports.html">Reports</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
          <span class="navbar-text">
              In partnership with: &nbsp; 
              <img src="img/dswd.png" class="d-inline-block align-center" alt="" style="height: 25px;"></img>
          </span>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</header>
<!--header end-->

<!-- Page Content -->
<div class="container">

  <!--main content start-->
  <section id="main-content">
      <section class="wrapper" style="padding-top: 30px;">

            <div class="row">

                <!-- Reports -->
                <div class="col-md-8">
                  <div class="well">

                    <h1 class="page-header">Public Announcements</h1>

                    <!-- First Announcement -->
                    <h2>*Insert DSWD announcement (eg. Adoption Consciousness Celebration 2017)*</h2>
                    <p><i class="fa fa-clock-o"></i> Posted on August 28, 2013 at 10:00 PM</p>
                    <hr>
                    <a href="">
                        <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                    </a>
                    <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                    <a class="btn btn-primary" href="main_announcement.html">Read More <i class="fa fa-angle-right"></i></a>

                    <hr>

                    <!-- Second Announcement -->
                    <h2>*Insert DSWD announcement (eg. Adoption Consciousness Celebration 2017)*</h2>
                    <p><i class="fa fa-clock-o"></i> Posted on August 28, 2013 at 10:00 PM</p>
                    <hr>
                    <a href="">
                        <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                    </a>
                    <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                    <a class="btn btn-primary" href="main_announcement.html">Read More <i class="fa fa-angle-right"></i></a>

                    <hr>

                    <!-- Third Announcement -->
                    <h2>*Insert DSWD announcement (eg. Adoption Consciousness Celebration 2017)*</h2>
                    <p><i class="fa fa-clock-o"></i> Posted on August 28, 2013 at 10:00 PM</p>
                    <hr>
                    <a href="">
                        <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                    </a>
                    <hr>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                    <a class="btn btn-primary" href="main_announcement.html">Read More <i class="fa fa-angle-right"></i></a>


                    <!-- Pagination -->
                    <div class="text-center">
                        <ul class="pagination">
                            <li class="previous"><a href="#">« Older</a></li>
                            <li><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li class="next"><a href="#">Newer »</a></li>
                        </ul>
                    </div>

                  </div>
                </div>

                <!-- Sidebar column -->
                <div class="col-md-4">

                    <!-- Search -->
                    <div class="well">
                        <h4>Search</h4>
                        <div class="input-group">
                            <input type="text" class="form-control">
                            <span class="input-group-btn">
                                <button class="btn btn-primary" type="button"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </div>
                </div>

            </div>

     </section>
   </section>
   <!--main content end-->

</div>
<!-- End container -->

<!-- footer -->
<div class="footer-grids" style="border-top: 4px solid #f41870;">
    <div class="footer one">
        <h3>More About Company</h3>
        <p> Nemo enim ipsam voluptatem quia
        voluptas sit aspernatur aut odit aut fugit, 
        sed quia consequuntur magni dolores eos qui 
        ratione voluptatem sequi nesciunt.</p>
        <p class="adam">- Department of Social Welfare and Development</p>
        <div class="clear"></div>
    </div>
    <div class="footer two">
        <h3>Keep Connected</h3>
        <ul>
            <li><a class="fb" href="#"><i></i>Like us on Facebook</a></li>
            <li><a class="fb1" href="#"><i></i>Follow us on Twitter</a></li>
            <li><a class="fb2" href="#"><i></i>Add us on Google Plus</a></li>
            <li><a class="fb3" href="#"><i></i>Follow us on Dribbble</a></li>
            <li><a class="fb4" href="#"><i></i>Follow us on Pinterest</a></li>
        </ul>
    </div>
    <div class="footer three">
        <h3>Contact Information</h3>
        <ul>
            <li>The company name <span>Lorem ipsum dolor,</span>Glasglow Dr 40 Fe 72.  </li>
            <li>1234567890  </li>
            <li><a href="mailto:info@example.com">contact@example.com</a> </li>
        </ul>
    </div>
    <div class="clear"></div>
</div>
<div class="copy-right-grids">
    <div class="copy-left">
            <p class="footer-gd">Designed by Team ACE | Powered by BootstrapMade</a></p>
    </div>
    <div class="copy-right">
        <ul>
            <li><a href="#">Company Information</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms & Conditions</a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>

<!-- javascripts -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="js/scripts.js"></script>

<!-- Script to Activate the Carousel -->
<script>
$('.carousel').carousel({
    interval: 5000 //changes the speed
})
</script>

</body>

</html>
