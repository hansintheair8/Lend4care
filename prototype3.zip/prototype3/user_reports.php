<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care - Reports</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/temp.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->

</head>

<body class="parallax">

<!--header start-->
<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.php" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li><a href="public_announcements.php">Public Announcements</a></li>
          <li><a href="public_reports.php">Reports</a></li>
      </ul>

      <div class="top-nav notification-row" style="margin-top: 1px;">                
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">
            <li>
                <a href="index.php">
                    <i class="icon-home-l"></i>
                </a>
            </li>

            <!-- notification start-->
            <li id="alert_notificatoin_bar" class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                    <i class="icon-bell-l"></i>
                    <span class="badge bg-important">7</span>
                </a>
                <ul class="dropdown-menu extended notification">
                    <div class="notify-arrow notify-arrow-blue"></div>
                    <li>
                        <p class="blue">You have 3 new notifications</p>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-primary"><i class="icon_like"></i></span> 
                            Congratulations, your report has been heard!
                            <span class="small italic pull-right">5 mins</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-danger"><i class="icon_book_alt"></i></span> 
                            Your report has been disapproved.
                            <span class="small italic pull-right">1 hr</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-success"><i class="icon_like"></i></span> 
                            Your report has been approved.
                            <span class="small italic pull-right"> Today</span>
                        </a>
                    </li>                            
                    <li>
                        <a href="#">See all notifications</a>
                    </li>
                </ul>
            </li>
            <!-- notification end-->

            <!-- user dropdown start-->
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="profile-ava">
                        <img alt="" src="<?php echo $_SESSION["profilepic"]; ?>" style="width:30px; height:30px;">
                    </span>
                    <span class="username"><?php echo $_SESSION["fname"]." ".$_SESSION["lname"]; ?></span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu extended logout">
                    <div class="log-arrow-up"></div>
                    <li class="eborder-top">
                        <a href="user_profile.php"><i class="icon_profile"></i> My Profile</a>
                    </li>
                    <li>
                        <a href="user_reports.php"><i class="icon_documents"></i> My Reports</a>
                    </li>
                    <li>
                        <a href="account_settings.php"><i class="icon_mail_alt"></i> Account Settings</a>
                    </li>
                    <li>
                        <a href="log-out.php"><i class="icon_key_alt"></i> Log Out</a>
                    </li>
                </ul>
            </li>
            <!-- user dropdown end -->

        </ul>
        <!-- notificatoin dropdown end-->
      </div>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</header>
<!--header end-->

<!-- Page Content -->
<div class="container">

      <!--main content start-->
      <section id="main-content">
          <section class="wrapper" style="padding-top: 30px;">
              <div class="row">
                <!-- profile -->
                <div class="col-lg-12">
                    <div class="profile-widget profile-widget-info">
                          <div class="panel-body">
                            <div class="col-lg-2 col-sm-2">
                              <h4><?php echo $_SESSION["fname"]." ".$_SESSION["lname"]; ?></h4>               
                              <div class="follow-ava">
                                  <img src="<?php echo $_SESSION["profilepic"]; ?>" alt="" style="width:75px; height:75px;">
                              </div>
                            </div>
                            <div class="col-lg-4 col-sm-4 follow-info">
                                <p>Hello I’m Andre Cabatingan, team leader of TEAM Ace. Charot.</p>
                                <p>@<?php echo $_SESSION["uname"]; ?></p>
                            </div>
                          </div>
                    </div>
                </div>
              </div>
              <!-- page start-->
              <div class="row">
                 <div class="col-lg-12">
                    <section class="panel">
                          <header class="panel-heading tab-bg-info">
                              <ul class="nav nav-tabs">
                                  <li class="active">
                                      <a data-toggle="tab" href="#my-reports">
                                          My Reports
                                      </a>
                                  </li>
                                  <li>
                                      <a data-toggle="tab" href="#followed-reports">
                                          Followed Reports
                                      </a>
                                  </li>
                                  <li>
                                      <a data-toggle="tab" href="#drafts">
                                          Drafts
                                      </a>
                                  </li>
                                  <li>
                                      <a data-toggle="tab" href="#create-report">
                                          Create Report
                                      </a>
                                  </li>
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">
                                  <!-- My reports -->
                                  <div id="my-reports" class="tab-pane active">
                                      <div class="profile-activity">                                          
                                          <div class="act-time">                                      
                                              <div class="activity-body act-in">
                                                  <span class="arrow"></span>
                                                  <div class="text">
                                                      <a href="#" class="activity-img"><img class="avatar" src="<?php echo $_SESSION["profilepic"]; ?>" alt="" style="width:45px; height:45px"></a>
                                                      <p><a href="#">Andre Cabatingan </a> at 5:25am, 30th Octmber 2014</p>
                                                      </br>
                                                      <h3>*Insert Name of Case (eg. Lolo Alfredo)*</h3>
                                                      <h4>Sector: Senior Citizen</h4>
                                                      <a href="#">
                                                          <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                                                      </a>
                                                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                                                      <a class="btn btn-default" href="main_report.php">Read More <i class="fa fa-angle-right"></i></a>
                                                  </div>
                                              </div>
                                          </div>

                                          <!-- Pagination -->
                                          <div class="text-center">
                                            <ul class="pagination">
                                                <li class="previous"><a href="#">« Older</a></li>
                                                <li><a href="#">1</a></li>
                                                <li><a href="#">2</a></li>
                                                <li><a href="#">3</a></li>
                                                <li><a href="#">4</a></li>
                                                <li><a href="#">5</a></li>
                                                <li class="next"><a href="#">Newer »</a></li>
                                            </ul>
                                          </div>

                                      </div>
                                  </div>
                                  <!-- End My Reports -->

                                  <!-- Followed reports -->
                                  <div id="followed-reports" class="tab-pane">
                                      <div class="profile-activity">                                          
                                          <div class="act-time">                                      
                                              <div class="activity-body act-in">
                                                  <span class="arrow"></span>
                                                  <div class="text">
                                                      <a href="#" class="activity-img"><img class="avatar" src="img/dp.jpg" alt="" style="width:45px; height:45px"></a>
                                                      <p><a href="#">Andre Cabatingan </a> at 5:25am, 30th Octmber 2014</p>
                                                      </br>
                                                      <h3>*Insert Name of Case (eg. Lolo Alfredo)*</h3>
                                                      <h4>Sector: Senior Citizen</h4>
                                                      <a href="#">
                                                          <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                                                      </a>
                                                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                                                      <a class="btn btn-default" href="main_report.php">Read More <i class="fa fa-angle-right"></i></a>
                                                  </div>
                                              </div>
                                          </div>
                                          <div class="act-time">                                      
                                              <div class="activity-body act-in">
                                                  <span class="arrow"></span>
                                                  <div class="text">
                                                      <a href="#" class="activity-img"><img class="avatar" src="img/dp.jpg" alt="" style="width:45px; height:45px"></a>
                                                      <p><a href="#">Andre Cabatingan </a> at 5:25am, 30th Octmber 2014</p>
                                                      </br>
                                                      <h3>*Insert Name of Case (eg. Lolo Alfredo)*</h3>
                                                      <h4>Sector: Senior Citizen</h4>
                                                      <a href="#">
                                                          <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                                                      </a>
                                                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                                                      <a class="btn btn-default" href="main_report.php">Read More <i class="fa fa-angle-right"></i></a>
                                                  </div>
                                              </div>
                                          </div>
                                          <div class="act-time">                                      
                                              <div class="activity-body act-in">
                                                  <span class="arrow"></span>
                                                  <div class="text">
                                                      <a href="#" class="activity-img"><img class="avatar" src="img/dp.jpg" alt="" style="width:45px; height:45px"></a>
                                                      <p><a href="#">Andre Cabatingan </a> at 5:25am, 30th Octmber 2014</p>
                                                      </br>
                                                      <h3>*Insert Name of Case (eg. Lolo Alfredo)*</h3>
                                                      <h4>Sector: Senior Citizen</h4>
                                                      <a href="#">
                                                          <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                                                      </a>
                                                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                                                      <a class="btn btn-default" href="main_report.php">Read More <i class="fa fa-angle-right"></i></a>
                                                  </div>
                                              </div>
                                          </div>

                                          <!-- Pagination -->
                                          <div class="text-center">
                                            <ul class="pagination">
                                                <li class="previous"><a href="#">« Older</a></li>
                                                <li><a href="#">1</a></li>
                                                <li><a href="#">2</a></li>
                                                <li><a href="#">3</a></li>
                                                <li><a href="#">4</a></li>
                                                <li><a href="#">5</a></li>
                                                <li class="next"><a href="#">Newer »</a></li>
                                            </ul>
                                          </div>

                                      </div>
                                  </div>
                                  <!-- End Followed Reports -->

                                  <!-- Drafts -->
                                  <div id="drafts" class="tab-pane">
                                      <div class="profile-activity">                                          
                                          <div class="act-time">                                      
                                              <div class="activity-body act-in">
                                                  <span class="arrow"></span>
                                                  <div class="text">
                                                      <a href="#" class="activity-img"><img class="avatar" src="img/dp.jpg" alt="" style="width:45px; height:45px"></a>
                                                      <p><a href="#">Andre Cabatingan </a> at 5:25am, 30th Octmber 2014</p>
                                                      </br>
                                                      <h3>*Insert Name of Case (eg. Lolo Alfredo)*</h3>
                                                      <h4>Sector: Senior Citizen</h4>
                                                      <a href="#">
                                                          <img class="img-responsive img-hover" src="img/bangtan2.jpg" alt="">
                                                      </a>
                                                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore, veritatis, tempora, necessitatibus inventore nisi quam quia repellat ut tempore laborum possimus eum dicta id animi corrupti debitis ipsum officiis rerum.</p>
                                                      <a class="btn btn-default" href="main_report.php">Read More <i class="fa fa-angle-right"></i></a>
                                                  </div>
                                              </div>
                                          </div>

                                          <!-- Pagination -->
                                          <div class="text-center">
                                            <ul class="pagination">
                                                <li class="previous"><a href="#">« Older</a></li>
                                                <li><a href="#">1</a></li>
                                                <li><a href="#">2</a></li>
                                                <li><a href="#">3</a></li>
                                                <li><a href="#">4</a></li>
                                                <li><a href="#">5</a></li>
                                                <li class="next"><a href="#">Newer »</a></li>
                                            </ul>
                                          </div>

                                      </div>
                                  </div>
                                  <!-- Drafts -->

                                  <!-- Create Report -->
                                  <div id="create-report" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h1> Create Report</h1>
                                              <form class="form-horizontal" action="addprocess.php" role="form" method="POST" enctype="multipart/form-data">                                                  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Evidence</label>
                                                      <div class="col-lg-6">
                                                          <label for="exampleInputFile">Upload Photo/Video</label>
                                                          <input type="file" name="fileToUpload" id="exampleInputFile" required/>
                                                      </div>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Sector</label>
                                                      <div class="col-lg-6">
                                                        <select name="sector" class="form-control" required/>
                                                            <option value="1">Abused Children</option>
                                                            <option value="2">Senior Citizens</option>
                                                            <option value="3">Disabled Citizens</option>
                                                        </select>
                                                      </div>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Situation</label>
                                                      <div class="col-lg-10">
                                                          <textarea name="situation" id="" class="form-control" cols="30" rows="13" placeholder="Tell us what happened . . ." required/></textarea>
                                                      </div>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Subject</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="subject" id="" required/>
                                                      </div>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Place Sighted</label>
                                                      <div class="col-lg-6">
                                                            <label class="col-lg-2">Region</label>
                                                            <select name="sight_region" class="form-control" style="width:250px;" required/>
                                                                <option value="National Capital Region">National Capital Region</option>
                                                            </select>
                                                            </br>
                                                            <label class="col-lg-2">State</label>
                                                            <select name="sight_state" class="form-control" style="width:250px;" required/>
                                                                <option value="Metro Manila">Metro Manila</option>
                                                            </select>
                                                            </br>
                                                            <label class="col-lg-2">City</label>
                                                            <select name="sight_city" class="form-control" style="width:250px;" required/>
                                                                <option value="Manila">Manila</option>
                                                            </select>
                                                            </br>
                                                            <label class="col-lg-2">District</label>
                                                            <select name="sight_district" class="form-control" style="width:250px;" required/>
                                                                <option value="District 1">District 1</option>
                                                            </select>
                                                            </br>
                                                            <div class="col-lg-4">
                                                                <input type="text" class="form-control" name="sight_no" id="" placeholder="No." required/>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <input type="text" class="form-control" name="sight_st" id="" placeholder="Street" required/>
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <input type="text" class="form-control" name="sight_brgy" id="" placeholder="Barangay" required/>
                                                            </div>
                                                      </div>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Date Sighted</label>
                                                      <div class="col-lg-8">
                                                            <input type="date" name="sight_date" class="form-control" required />
                                                      </div>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Time Sighted</label>
                                                      <div class="col-lg-6">
                                                            <div class="col-lg-3">
                                                                <select name="time_hour" class="form-control" required/>
                                                                    <option value="01">1</option>
                                                                    <option value="02">2</option>
                                                                    <option value="03">3</option>
                                                                    <option value="04">4</option>
                                                                    <option value="05">5</option>
                                                                    <option value="06">6</option>
                                                                    <option value="07">7</option>
                                                                    <option value="08">8</option>
                                                                    <option value="09">9</option>
                                                                    <option value="10">10</option>
                                                                    <option value="11">11</option>
                                                                    <option value="12">12</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <select name="time_min" class="form-control" required/>
                                                                    <option>00</option>
                                                                    <option>05</option>
                                                                    <option>10</option>
                                                                    <option>15</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <select class="form-control" required/>
                                                                    <option>AM</option>
                                                                    <option>PM</option>
                                                                </select>
                                                            </div>
                                                      </div>
                                                  </div>

                                                  <div class="form-group">
                                                      <div class="col-lg-offset-2 col-lg-10 text-right">
                                                          <button type="button" class="btn btn-default">Cancel</button>
                                                          <button type="button" class="btn btn-default">Save as Draft</button>
                                                          <button type="submit" name="addreportbtn" formaction="addprocess.php" class="btn btn-primary">Submit for Approval</button>
                                                      </div>
                                                  </div>
                                              </form>
                                          </div>
                                      </section>
                                  </div>
                                  <!-- End Create Report -->
                              </div>
                          </div>
                    </section>
                 </div>
              </div>

              <!-- page end-->
          </section>
      </section>
      <!--main content end-->

</div>
<!-- container end -->

<!-- footer -->
<div class="footer-grids" style="border-top: 4px solid #f41870;">
    <div class="footer one">
        <h3>More About Company</h3>
        <p> Nemo enim ipsam voluptatem quia
        voluptas sit aspernatur aut odit aut fugit, 
        sed quia consequuntur magni dolores eos qui 
        ratione voluptatem sequi nesciunt.</p>
        <p class="adam">- Department of Social Welfare and Development</p>
        <div class="clear"></div>
    </div>
    <div class="footer two">
        <h3>Keep Connected</h3>
        <ul>
            <li><a class="fb" href="#"><i></i>Like us on Facebook</a></li>
            <li><a class="fb1" href="#"><i></i>Follow us on Twitter</a></li>
            <li><a class="fb2" href="#"><i></i>Add us on Google Plus</a></li>
            <li><a class="fb3" href="#"><i></i>Follow us on Dribbble</a></li>
            <li><a class="fb4" href="#"><i></i>Follow us on Pinterest</a></li>
        </ul>
    </div>
    <div class="footer three">
        <h3>Contact Information</h3>
        <ul>
            <li>The company name <span>Lorem ipsum dolor,</span>Glasglow Dr 40 Fe 72.  </li>
            <li>1234567890  </li>
            <li><a href="mailto:info@example.com">contact@example.com</a> </li>
        </ul>
    </div>
    <div class="clear"></div>
</div>
<div class="copy-right-grids">
    <div class="copy-left">
            <p class="footer-gd">Designed by Team ACE | Powered by BootstrapMade</a></p>
    </div>
    <div class="copy-right">
        <ul>
            <li><a href="#">Company Information</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms & Conditions</a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>

<!-- javascripts -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="js/scripts.js"></script>

<script>

  //knob
  $(".knob").knob();

</script>


</body>
</html>
