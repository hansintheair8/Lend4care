<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care - Login</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet">
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/temp.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body class="parallax"> <!-- class="login-img3-body" -->

<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.html" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li class="active"><a href="index.html">Home</a></li>
          <li><a href="public_announcements.html">Public Announcements</a></li>
          <li><a href="public_reports.html">Reports</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
          <span class="navbar-text">
              In partnership with: &nbsp; 
              <img src="img/dswd.png" class="d-inline-block align-center" alt="" style="height: 25px;"></img>
          </span>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</header>

<div class="container">

  <div class="row">
	    <div class="col-sm-8 col-sm-offset-2">
	        <div class="wizard-container">

	            <div class="card wizard-card" data-color="hotpink" id="wizardProfile" style="background-color: #f5f5f5;">
	                <form role="form" action="addprocess.php" method="POST" enctype="multipart/form-data">
	                	<div class="wizard-header text-center">
	                    	<h4 class="wizard-title"><a href="index.html"><img src="img/lend4care.png" style="height: 70px;"></a></h4>
	                	</div>

						<div class="wizard-navigation">
							<div class="progress-with-circle" style="background-color: #e8e5e5;">
							     <div class="progress-bar" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="3" style="width: 21%;"></div>
							</div>
							<ul>
	                            <li>
									<a href="#about" data-toggle="tab">
										<div class="icon-circle">
											<i class="ti-user"></i>
										</div>
										Personal Information
									</a>
								</li>
	                            <li>
									<a href="#account" data-toggle="tab">
										<div class="icon-circle">
											<i class="ti-settings"></i>
										</div>
										Account Information
									</a>
								</li>
	                            <li>
									<a href="#address" data-toggle="tab">
										<div class="icon-circle">
											<i class="ti-map"></i>
										</div>
										Terms and Conditions
									</a>
								</li>
	                        </ul>
						</div>
	                    <div class="tab-content">
	                        <div class="tab-pane" id="about">
	                        	<div class="row">
									<h3 class="info-text">Register</h3>
									<div class="col-sm-4 col-sm-offset-1">
										<div class="picture-container">
											<div class="picture">
												<img src="img/default-avatar.jpg" class="picture-src" id="wizardPicturePreview" title="" />
												<input type="file" name="fileToUpload" id="wizard-picture">
											</div>
											<h6>Choose Picture</h6>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label>First Name:</label>
											<input name="fname" type="text" class="form-control" pattern="[a-zA-Z]*" required/>
										</div>
										<div class="form-group">
											<label>Middle Name:</label>
											<input name="mname" type="text" class="form-control" pattern="[a-zA-Z]*" required/>
										</div>
										<div class="form-group">
											<label>Last Name:</label>
											<input name="lname" type="text" class="form-control" pattern="[a-zA-Z]*" required/>
										</div>
									</div>
									<div class="col-sm-10 col-sm-offset-1">
										<div class="form-group">
					                        <label>Gender:</label>
					                        </br>
					                        <label class="radio-inline">
					                          <input type="radio" name="gender" value="M">Male
					                        </label>
					                        <label class="radio-inline">
					                          <input type="radio" name="gender" value="F">Female
					                        </label>
					                    </div>
					                    <div class="form-group">
					                        <label>Birthday:</label>
					                        <input name="bday" type="date" class="form-control" required/>
					                    </div>
					                    <div class="form-group">
					                    	<label for="subject">Contacts:</label>
					                    	</br>
					                        <div class="col-sm-6">
						                        <label>Phone Number</label>
						                        <input name="landline" type="text" class="form-control" pattern="[0-9]*">
					                    	</div>
					                    	<div class="col-sm-6">
						                        <label>Mobile Number</label>
						                        <input name="mobilenum" type="text" class="form-control" pattern="[0-9]*">
					                        </div>
					                        </br>
					                        </br>
					                        </br>
					                    </div>
					                    <div class="form-group">
					                        <label for="subject">Address:</label>
					                        </br>
					                        <div class="col-sm-6">
						                        <label>Region</label>
						                        <select name="region" class="form-control" required/>
						                            <option value="National Capital Region">National Capital Region</option>
						                        </select>
					                        </div>
					                        <div class="col-sm-6">
						                        <label>State</label>
						                        <select name="state" class="form-control" required/>
						                            <option value="Metro Manila">Metro Manila</option>
						                        </select>
					                        </div>
					                        <div class="col-sm-6">
						                        <label>City</label>
						                        <select name="city" class="form-control" required/>
						                            <option value="Quezon City">Quezon City</option>
						                        </select>
						                    </div>
						                    <div class="col-sm-6">
						                        <label>District</label>
						                        <select name="district" class="form-control" required/>
						                            <option value="District 1">District 1</option>
						                        </select>
						                    </div>
						                    <div class="col-sm-2">
						                        <label>Street No.</label>
						                        <input type="text" class="form-control" name="addressno" id="" pattern="[0-9]*" placeholder="No." required/>
					                        </div>
					                        <div class="col-sm-4">
						                        <label>Street Name</label>
						                        <input type="text" class="form-control" name="addressstreet" id="" pattern="[a-zA-Z]*" placeholder="Street" required/>
					                        </div>
					                        <div class="col-sm-6">
						                        <label>Barangay</label>
						                        <input type="text" class="form-control" name="addressbarangay" id="" pattern="[a-zA-Z]*" placeholder="Barangay" required/>
					                        </div>
					                    </div>
									</div>
								</div>
	                        </div>
	                        <div class="tab-pane" id="account">
	                            <h3 class="info-text">Register</h3>
	                            <div class="row">
	                                <div class="col-sm-10 col-sm-offset-1">
										<div class="form-group">
											<label>User Name:</label>
											<input name="username" type="text" class="form-control" pattern="[a-zA-Z]*" required/>
										</div>
										<div class="form-group">
											<label>Email:</label>
											<input name="email" type="email" class="form-control">
										</div>
										<div class="form-group">
											<label>Password:</label>
											<input name="password" type="password" class="form-control" pattern="[a-zA-Z]*" required/>
										</div>
										<div class="form-group">
											<label>Confirm Password:</label>
											<input name="conpassword" type="password" class="form-control" pattern="[a-zA-Z]*" required/>
										</div>
									</div>
	                            </div>
	                        </div>
	                        <div class="tab-pane" id="address">
	                            <div class="row">
	                                <div class="col-sm-12">
	                                    <h3 class="info-text">Register</h3>
	                                </div>
	                                
	                            </div>
	                        </div>
	                    </div>
	                    <div class="wizard-footer">
	                        <div class="pull-right">
	                            <input type='button' class='btn btn-next btn-fill btn-primary' name='next' value='Next' />
	                            <input type='submit' class='btn btn-finish btn-fill btn-primary' name='registerbtn' formaction="addprocess.php" value='Finish' />
	                        </div>

	                        <div class="pull-left">
	                            <input type='button' class='btn btn-previous btn-default' name='previous' value='Previous' />
	                        </div>
	                        <div class="clearfix"></div>
	                    </div>
	                </form>
	            </div>
	        </div> <!-- wizard container -->
	    </div>
	</div><!-- end row -->

</div>

<!-- footer -->
<div class="footer-grids" style="border-top: 4px solid #f41870;">
    <div class="footer one">
        <h3>More About Company</h3>
        <p> Nemo enim ipsam voluptatem quia
        voluptas sit aspernatur aut odit aut fugit, 
        sed quia consequuntur magni dolores eos qui 
        ratione voluptatem sequi nesciunt.</p>
        <p class="adam">- Department of Social Welfare and Development</p>
        <div class="clear"></div>
    </div>
    <div class="footer two">
        <h3>Keep Connected</h3>
        <ul>
            <li><a class="fb" href="#"><i></i>Like us on Facebook</a></li>
            <li><a class="fb1" href="#"><i></i>Follow us on Twitter</a></li>
            <li><a class="fb2" href="#"><i></i>Add us on Google Plus</a></li>
            <li><a class="fb3" href="#"><i></i>Follow us on Dribbble</a></li>
            <li><a class="fb4" href="#"><i></i>Follow us on Pinterest</a></li>
        </ul>
    </div>
    <div class="footer three">
        <h3>Contact Information</h3>
        <ul>
            <li>The company name <span>Lorem ipsum dolor,</span>Glasglow Dr 40 Fe 72.  </li>
            <li>1234567890  </li>
            <li><a href="mailto:info@example.com">contact@example.com</a> </li>
        </ul>
    </div>
    <div class="clear"></div>
</div>
<div class="copy-right-grids">
    <div class="copy-left">
            <p class="footer-gd">Designed by Team ACE | Powered by BootstrapMade</a></p>
    </div>
    <div class="copy-right">
        <ul>
            <li><a href="#">Company Information</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms & Conditions</a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>


<!-- javascripts -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.bootstrap.wizard.js" type="text/javascript"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="js/scripts.js"></script>
<script src="js/paper-bootstrap-wizard.js" type="text/javascript"></script>
<script src="js/jquery.validate.min.js" type="text/javascript"></script>

</body>
</html>
