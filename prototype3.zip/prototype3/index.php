<?php
session_start();

ini_set("display_errors", "0");
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/modern-business.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/temp.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->

</head>

<body class="parallax">

<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.php" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="public_announcements.php">Public Announcements</a></li>
          <li><a href="public_reports.php">Reports</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
          <span class="navbar-text">
              In partnership with: &nbsp; 
              <img src="img/dswd.png" class="d-inline-block align-center" alt="" style="height: 25px;"></img>
          </span>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</header>

<?php if($_SESSION["con"]=="1"): ?>
<!-- This will be the navbar when user logged in -->
<!--header start-->
<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">

    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.php" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li><a href="public_announcements.php">Public Announcements</a></li>
          <li><a href="public_reports.php">Reports</a></li>
      </ul>

      <div class="top-nav notification-row" style="margin-top: 1px;">                

        <ul class="nav pull-right top-menu">
            <li>
                <a href="index.php">
                    <i class="icon-home-l"></i>
                </a>
            </li>

            <li id="alert_notificatoin_bar" class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                    <i class="icon-bell-l"></i>
                    <span class="badge bg-important">7</span>
                </a>
                <ul class="dropdown-menu extended notification">
                    <div class="notify-arrow notify-arrow-blue"></div>
                    <li>
                        <p class="blue">You have 3 new notifications</p>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-primary"><i class="icon_like"></i></span> 
                            Congratulations, your report has been heard!
                            <span class="small italic pull-right">5 mins</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-danger"><i class="icon_book_alt"></i></span> 
                            Your report has been disapproved.
                            <span class="small italic pull-right">1 hr</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-success"><i class="icon_like"></i></span> 
                            Your report has been approved.
                            <span class="small italic pull-right"> Today</span>
                        </a>
                    </li>                            
                    <li>
                        <a href="#">See all notifications</a>
                    </li>
                </ul>
            </li>

            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="profile-ava">
                        <img alt="" src="<?php echo $_SESSION["profilepic"]; ?>" style="width:30px; height:30px;">
                    </span>
                    <span class="username"><?php echo $_SESSION["fname"]." ".$_SESSION["lname"];?></span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu extended logout">
                    <div class="log-arrow-up"></div>
                    <li class="eborder-top">
                        <a href="user_profile.php"><i class="icon_profile"></i> My Profile</a>
                    </li>
                    <li>
                        <a href="user_reports.php"><i class="icon_documents"></i> My Reports</a>
                    </li>
                    <li>
                        <a href="account_settings.php"><i class="icon_mail_alt"></i> Account Settings</a>
                    </li>
                    <li>
                        <a href="log-out.php"><i class="icon_key_alt"></i> Log Out</a>
                    </li>
                </ul>
            </li>

        </ul>
      </div>

    </div>
  </div>
</header> 
<!--header end-->
<?php endif; ?>

<!-- Set class col-md-8 to col-lg-12 if the user logged in -->
<?php if($_SESSION["con"]=="1"): ?>
<div class="col-md-12">
<?php else: ?>
<div class="col-md-8">
<?php endif; ?>
    
  <div class="slide-wrapper">

     <!-- Change style of #homepage-feature if the user logged in -->
      
     <!-- <div id="homepage-feature" class="carousel slide"  style="margin: 80px 18px 0px 20px;"> -->
     <div id="homepage-feature" class="carousel slide"  style="margin: 80px 0px 0px 20px;">

        <ol class="carousel-indicators">
           <li data-target="#homepage-feature" data-slide-to="0" class="active"></li>
           <li data-target="#homepage-feature" data-slide-to="1"></li>
        </ol>

        <div class="carousel-inner">
           <div class="item active" style="background-image:url(img/bangtan.jpg)">
              <div class="carousel-caption">
                 <h1>Changes to the Grid</h1>
                 <p>Bootstrap 3 still features a 12-column grid, but many of the CSS class names have completely changed.</p>
                 <p><a class="btn btn-large btn-primary" href="#">Learn more</a>
                 </p>
              </div>
           </div>

           <div class="item">
              <div class="carousel-caption">
                 <h1>Percentage-based sizing</h1>
                 <p>With "mobile-first" there is now only one percentage-based grid.</p>
                 <p><a class="btn btn-large btn-primary" href="#">Browse gallery</a>
                 </p>
              </div>
           </div>
        </div>

     </div>
  </div>
</div>


<!-- Hide login form when user logged in-->
    
<?php if($_SESSION["con"]==NULL): ?>
<div class="col-lg-4">
  <form class="login-form" method="POST">        
    <div class="login-wrap">
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" class="form-control" placeholder="Username" name="user" autofocus required>
        </div>
        <div class="input-group">
            <span class="input-group-addon"><i class="icon_key_alt"></i></span>
            <input type="password" class="form-control" placeholder="Password" name="pass" required>
        </div>
        <label class="checkbox">
            <input type="checkbox" value="remember-me"> Remember me
            <span class="pull-right"> <a href="#"> Forgot Password?</a></span>
        </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" formaction="loginprocess.php">Login</button>
        
        <a href="register.php"><button class="btn btn-info btn-lg btn-block" type="button">Register</button></a>
    </div>
  </form>
</div>
<?php endif; ?>

<!-- Page Content -->
<div class="container">


    <!-- insert main content here (geneveve) -->


    <!-- end main content -->

</div>
<!-- container -->

<!-- footer -->
<div class="footer-grids" style="border-top: 4px solid #f41870;">
    <div class="footer one">
        <h3>More About Company</h3>
        <p> Nemo enim ipsam voluptatem quia
        voluptas sit aspernatur aut odit aut fugit, 
        sed quia consequuntur magni dolores eos qui 
        ratione voluptatem sequi nesciunt.</p>
        <p class="adam">- Department of Social Welfare and Development</p>
        <div class="clear"></div>
    </div>
    <div class="footer two">
        <h3>Keep Connected</h3>
        <ul>
            <li><a class="fb" href="#"><i></i>Like us on Facebook</a></li>
            <li><a class="fb1" href="#"><i></i>Follow us on Twitter</a></li>
            <li><a class="fb2" href="#"><i></i>Add us on Google Plus</a></li>
            <li><a class="fb3" href="#"><i></i>Follow us on Dribbble</a></li>
            <li><a class="fb4" href="#"><i></i>Follow us on Pinterest</a></li>
        </ul>
    </div>
    <div class="footer three">
        <h3>Contact Information</h3>
        <ul>
            <li>The company name <span>Lorem ipsum dolor,</span>Glasglow Dr 40 Fe 72.  </li>
            <li>1234567890  </li>
            <li><a href="mailto:info@example.com">contact@example.com</a> </li>
        </ul>
    </div>
    <div class="clear"></div>
</div>
<div class="copy-right-grids">
    <div class="copy-left">
            <p class="footer-gd">Designed by Team ACE | Powered by BootstrapMade</a></p>
    </div>
    <div class="copy-right">
        <ul>
            <li><a href="#">Company Information</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms & Conditions</a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>

<!-- javascripts -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="js/scripts.js"></script>
<script src="js/temp-login.js"></script>

<!-- Activate the Carousel -->
<script>
$('.carousel').carousel({
    interval: 5000 //changes the speed
})
</script>

</body>

</html>
