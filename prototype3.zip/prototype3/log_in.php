<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care - Login</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/temp.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body class="parallax"> <!-- class="login-img3-body" -->

<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.php" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="public_announcements.html">Public Announcements</a></li>
          <li><a href="public_reports.html">Reports</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
          <span class="navbar-text">
              In partnership with: &nbsp; 
              <img src="img/dswd.png" class="d-inline-block align-center" alt="" style="height: 25px;"></img>
          </span>
      </ul>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</header>

<div class="container">

  <form class="login-form" method="POST" action="loginprocess.php">        
    <div class="login-wrap">
        <p class="login-img"><a href="index.php"><img src="img/lend4care.png" style="height: 70px;"></a></p>
        <div class="input-group">
          <span class="input-group-addon"><i class="icon_profile"></i></span>
          <input type="text" class="form-control" placeholder="Username" name="user" autofocus>
        </div>
        <div class="input-group">
            <span class="input-group-addon"><i class="icon_key_alt"></i></span>
            <input type="password" class="form-control" placeholder="Password" name="pass">
        </div>
        <label class="checkbox">
            <input type="checkbox" value="remember-me"> Remember me
            <span class="pull-right"> <a href="#"> Forgot Password?</a></span>
        </label>
        <button class="btn btn-primary btn-lg btn-block" type="submit" formaction="loginprocess.php">Login</button>
        <a href="register.php"><button class="btn btn-info btn-lg btn-block" type="button">Register</button></a>
    </div>
  </form>

</div>
<!-- end container -->

</body>
</html>
