<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/icon" href="img/favicon32x32.ico">

    <title>Lend4Care - Profile</title>

    <!-- Bootstrap CSS -->    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <link href="css/temp.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <script src="js/lte-ie7.js"></script>
    <![endif]-->

</head>

<body class="parallax">

<!--header start-->
<header class="header navbar-default navbar-fixed-top" style="border-bottom:4px solid #f41870; background-color: #f5f5f5;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" style="margin:7px 20px 5px 0px;">
      <a href="index.php" class="" ><img src="img/lend4care.png" style="height:40px;"></img></a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-left">
          <li><a href="public_announcements.php">Public Announcements</a></li>
          <li><a href="public_reports.php">Reports</a></li>
      </ul>

      <div class="top-nav notification-row" style="margin-top: 1px;">                
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">
            <li>
                <a href="index.php">
                    <i class="icon-home-l"></i>
                </a>
            </li>

            <!-- notification start-->
            <li id="alert_notificatoin_bar" class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                    <i class="icon-bell-l"></i>
                    <span class="badge bg-important">7</span>
                </a>
                <ul class="dropdown-menu extended notification">
                    <div class="notify-arrow notify-arrow-blue"></div>
                    <li>
                        <p class="blue">You have 3 new notifications</p>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-primary"><i class="icon_like"></i></span> 
                            Congratulations, your report has been heard!
                            <span class="small italic pull-right">5 mins</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-danger"><i class="icon_book_alt"></i></span> 
                            Your report has been disapproved.
                            <span class="small italic pull-right">1 hr</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="label label-success"><i class="icon_like"></i></span> 
                            Your report has been approved.
                            <span class="small italic pull-right"> Today</span>
                        </a>
                    </li>                            
                    <li>
                        <a href="#">See all notifications</a>
                    </li>
                </ul>
            </li>
            <!-- notification end-->

            <!-- user dropdown start-->
            <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="profile-ava">
                        <img alt="" src="<?php echo $_SESSION["profilepic"]; ?>" style="width:30px; height:30px;">
                    </span>
                    <span class="username"><?php echo $_SESSION["fname"]." ".$_SESSION["lname"]; ?></span>
                    <b class="caret"></b>
                </a>
                <ul class="dropdown-menu extended logout">
                    <div class="log-arrow-up"></div>
                    <li class="eborder-top">
                        <a href="user_profile.php"><i class="icon_profile"></i> My Profile</a>
                    </li>
                    <li>
                        <a href="user_reports.php"><i class="icon_documents"></i> My Reports</a>
                    </li>
                    <li>
                        <a href="account_settings.php"><i class="icon_mail_alt"></i> Account Settings</a>
                    </li>
                    <li>
                        <a href="log-out.php"><i class="icon_key_alt"></i> Log Out</a>
                    </li>
                </ul>
            </li>
            <!-- user dropdown end -->

        </ul>
        <!-- notificatoin dropdown end-->
      </div>

    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</header>
<!--header end-->

<!-- Page Content -->
<div class="container">

      <!--main content start-->
      <section id="main-content">
          <section class="wrapper" style="padding-top: 30px;">

              <div class="row">
                <!-- profile -->
                <div class="col-lg-12">
                    <div class="profile-widget profile-widget-info">
                          <div class="panel-body">
                            <div class="col-lg-2 col-sm-2">
                              <h4><?php echo $_SESSION["fname"]." ".$_SESSION["lname"]; ?></h4>               
                              <div class="follow-ava">
                                  <img src="<?php echo $_SESSION["profilepic"]; ?>" alt="" style="width:75px; height:75px;">
                              </div>
                            </div>
                            <div class="col-lg-4 col-sm-4 follow-info">
                                <p>Hello I’m Andre Cabatingan, team leader of TEAM Ace. Charot</p>
                                <p>@<?php echo $_SESSION["uname"]; ?></p>
                            </div>
                          </div>
                    </div>
                </div>
              </div>
              <!-- page start-->
              <div class="row">
                 <div class="col-lg-12">
                    <section class="panel">
                          <header class="panel-heading tab-bg-info">
                              <ul class="nav nav-tabs">
                                  <li class="active">
                                      <a data-toggle="tab" href="#profile">
                                          <i class="icon-home"></i>
                                          Profile
                                      </a>
                                  </li>
                                  <li>
                                      <a data-toggle="tab" href="#edit-profile">
                                          <i class="icon-user"></i>
                                          Profile Settings
                                      </a>
                                  </li>
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">

                                  <!-- profile -->
                                  <div id="profile" class="tab-pane active">
                                    <section class="panel">
                                      <div class="bio-graph-heading">
                                                Hello I’m Andre Cabatingan, *insert chu chu (description :D)*
                                      </div>
                                      <div class="panel-body bio-graph-info">
                                          <h1>Profile Information</h1>
                                          <div class="row">
                                              <div class="bio-row">
                                                  <p><span>First Name </span>: <?php echo $_SESSION["fname"]; ?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Last Name </span>: <?php echo $_SESSION["lname"]; ?></p>
                                              </div>         
                                              <div class="bio-row">
                                                  <p><span>Gender </span>: <?php echo $_SESSION["gender"]; ?></p>
                                              </div>                                     
                                              <div class="bio-row">
                                                  <p><span>Birthday</span>: <?php echo $_SESSION["bday"]; ?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Address </span>: <?php echo $_SESSION["address_no"]." ".$_SESSION["address_st"]." ".$_SESSION["address_brgy"]." ".$_SESSION["address_district"]." ".$_SESSION["address_city"]." ".$_SESSION["address_state"]." ".$_SESSION["address_region"]; ?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Mobile </span>: <?php echo $_SESSION["cp"]; ?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Phone </span>:  <?php echo $_SESSION["tp"]; ?></p>
                                              </div>
                                          </div>
                                      </div>
                                    </section>
                                    <section>
                                      <div class="row"></div>
                                    </section>
                                  </div>

                                  <!-- edit-profile -->
                                  <div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h1> Profile Settings</h1>
                                              <table class="table">
                                                <thead>
                                                    <th>USER INFORMATION</th>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>First Name</td>
                                                        <td><?php echo $_SESSION["fname"]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Last Name</td>
                                                        <td><?php echo $_SESSION["lname"]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Gender</td>
                                                        <td><?php echo $_SESSION["gender"]; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Birthday</td>
                                                        <td><?php echo $_SESSION["bday"]; ?></td>
                                                        <td>
                                                            <a data-toggle="modal" href="#myModal"><span class="glyphicon glyphicon-edit"></span></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Address</td>
                                                        <td><?php echo $_SESSION["address_no"]." ".$_SESSION["address_st"]." ".$_SESSION["address_brgy"]." ".$_SESSION["address_district"]." ".$_SESSION["address_city"]." ".$_SESSION["address_state"]." ".$_SESSION["address_region"]; ?></td>
                                                        <td>
                                                            <a data-toggle="modal" href="#myModal2"><span class="glyphicon glyphicon-edit"></span></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Mobile</td>
                                                        <td><?php echo $_SESSION["cp"]; ?></td>
                                                        <td>
                                                            <a data-toggle="modal" href="#myModal3"><span class="glyphicon glyphicon-edit"></span></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Phone</td>
                                                        <td><?php echo $_SESSION["tp"]; ?></td>
                                                        <td>
                                                            <a data-toggle="modal" href="#myModal4"><span class="glyphicon glyphicon-edit"></span></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                          </table>
                                          </div>
                                      </section>
                                  </div>
                              </div>
                          </div>
                      </section>
                 </div>
              </div>

              <!-- page end-->
          </section>
      </section>
      <!--main content end-->

</div>
<!-- container end -->

<!-- footer -->
<div class="footer-grids" style="border-top: 4px solid #f41870;">
    <div class="footer one">
        <h3>More About Company</h3>
        <p> Nemo enim ipsam voluptatem quia
        voluptas sit aspernatur aut odit aut fugit, 
        sed quia consequuntur magni dolores eos qui 
        ratione voluptatem sequi nesciunt.</p>
        <p class="adam">- Department of Social Welfare and Development</p>
        <div class="clear"></div>
    </div>
    <div class="footer two">
        <h3>Keep Connected</h3>
        <ul>
            <li><a class="fb" href="#"><i></i>Like us on Facebook</a></li>
            <li><a class="fb1" href="#"><i></i>Follow us on Twitter</a></li>
            <li><a class="fb2" href="#"><i></i>Add us on Google Plus</a></li>
            <li><a class="fb3" href="#"><i></i>Follow us on Dribbble</a></li>
            <li><a class="fb4" href="#"><i></i>Follow us on Pinterest</a></li>
        </ul>
    </div>
    <div class="footer three">
        <h3>Contact Information</h3>
        <ul>
            <li>The company name <span>Lorem ipsum dolor,</span>Glasglow Dr 40 Fe 72.  </li>
            <li>1234567890  </li>
            <li><a href="mailto:info@example.com">contact@example.com</a> </li>
        </ul>
    </div>
    <div class="clear"></div>
</div>
<div class="copy-right-grids">
    <div class="copy-left">
            <p class="footer-gd">Designed by Team ACE | Powered by BootstrapMade</a></p>
    </div>
    <div class="copy-right">
        <ul>
            <li><a href="#">Company Information</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms & Conditions</a></li>
        </ul>
    </div>
    <div class="clear"></div>
</div>

<!--Modals-->
<!-- Modal-->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit birthday</h4>
          </div>
          <div class="modal-body">
                <form role="form" action="editprocess.php" class="demo" method="POST">
                  <div class="form-group form-inline">
                        <label>Birthday</label>
                        <div style="width:250px;">
                            <input name="bdayedit" type="date" class="form-control" value = "<?php echo $_SESSION["bday"] ?>" required/>
                        </div>
                  </div>
                  <button type="submit" name="bdayeditBtn" class="btn btn-primary" formaction="editprocess.php">Edit</button>
                </form>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </div>
        </div>

      </div>
    </div>


    <!-- Modal2-->
    <div id="myModal2" class="modal fade" role="dialog">
      <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Address</h4>
          </div>
          <div class="modal-body">
                <form role="form" name="demo" action="editprocess.php" class="demo" method="POST">
                  <div class="form-group form-inline">

                        <label>Region</label>
                        <div style="width:250px;">
                        <select name="address_region" class="form-control" required/>
                            <option value="National Capital Region">National Capital Region</option>
                        </select>
                        </div>
                        <label>State</label>
                        <div style="width:250px;">
                        <select name="address_state" class="form-control" required/>
                            <option value="Metro Manila">Metro Manila</option>
                        </select>
                        </div>
                        <label>City</label>
                        <div style="width:250px;">
                        <select name="address_city" class="form-control" required/>
                            <option value="Manila">Manila</option>
                        </select>
                        </div>
                        <label>District</label>
                        <div style="width:250px;">
                        <select name="address_district" class="form-control" required/>
                            <option value="District 1">District 1</option>
                        </select>
                        </div>
                        <label>&nbsp;</label>
                        <div style="width:250px;">
                            <input type="text" class="form-control" name="address_no" id="" placeholder="No." value="<?php echo $_SESSION["address_no"]; ?>" required/>
                        </div>
                        <label>&nbsp;</label>
                        <div style="width:250px;">
                            <input type="text" class="form-control" name="address_street" id="" placeholder="Street" value="<?php echo $_SESSION["address_st"]; ?>" required/>
                        </div>
                        <label>&nbsp;</label>
                        <div style="width:250px;">
                            <input type="text" class="form-control" name="address_brgy" id="" placeholder="Barangay" value="<?php echo $_SESSION["address_brgy"]; ?>" required/>
                        </div>
                           
                  </div>
                  <button type="submit" name="addresseditBtn" formaction="editprocess.php" class="btn btn-primary">Edit</button>
                </form>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </div>
        </div>

      </div>
    </div>


    <!-- Modal3-->
    <div id="myModal3" class="modal fade" role="dialog">
      <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Mobile</h4>
          </div>
          <div class="modal-body">
                <form role="form" name="demo" action="editprocess.php" class="demo" method="POST">
                  <div class="form-group form-inline">
                    <label>Mobile Number</label>
                    <div style="width:250px;">
                        <input type="text" class="form-control" name="cpedit" value="<?php echo $_SESSION["cp"]; ?>" required/>
                    </div>
                    <label>Custom</label>
                    <div style="width:250px;">
                        <select name="" class="form-control" required/>
                            <option value="">Private</option>
                            <option value="">Public</option>
                        </select>
                    </div>
                  </div>

                  <button type="submit" name="cpeditBtn" formaction="editprocess.php" class="btn btn-primary">Edit</button>
                </form>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </div>
        </div>
    </div>


    <!-- Modal4-->
    <div id="myModal4" class="modal fade" role="dialog">
      <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Phone Number</h4>
          </div>
          <div class="modal-body">
                <form role="form" name="demo" action="editprocess.php" class="demo" method="POST">
                  <div class="form-group form-inline">
                    <label>Phone Number</label>
                    <div style="width:250px;">
                        <input type="text" class="form-control" name="tpedit" value="<?php echo $_SESSION["tp"]; ?> "required/>
                    </div>
                    <label>Custom</label>
                    <div style="width:250px;">
                        <select class="form-control" required/>
                            <option name="">Private</option>
                            <option name="">Public</option>
                        </select>
                    </div>
                  </div>

                  <button type="submit" name="tpeditBtn" formaction="editprocess.php" class="btn btn-primary">Edit</button>
                </form>
          </div>
          <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </div>
        </div>
    </div>
<!-- End Modals-->


<!-- javascripts -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- nice scroll -->
<script src="js/jquery.scrollTo.min.js"></script>
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>
<!-- jquery knob -->
<script src="assets/jquery-knob/js/jquery.knob.js"></script>
<!--custome script for all page-->
<script src="js/scripts.js"></script>

<script>

  //knob
  $(".knob").knob();

</script>


</body>
</html>
